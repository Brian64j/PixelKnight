from gamelib import*
#game object
game = Game (1200,800,"Pixel Knight")
#bk object
bk = Image("darkcastle.png",game)
game.setBackground(bk)
bk.resizeTo(game.width,game.height)
play = Image("play.png",game)
play.resizeBy(40)
play.y += 200
knight = Animation("tumblr_inline_o3of9pprYp1r43rse_250.png",4,game,768/4,232,13)
knight1 = Animation("tumblr_inline_o3oj9t9fnc1r43rse_400.png",7,game,1960/7,188,5)
monster = Animation("hoon-kim-gob-boss (3).png",5,game,2400/5,2400,6)
while not game.over:
    game.processInput()
    game.scrollBackground("left",2)
    play.draw()
    game.drawText("PIXEL KNIGHT",500,500)
    knight.draw()
    knight.moveTo(400,400)
    if play.collidedWith(mouse) and mouse.LeftClick:
        game.over = True
    
    game.update(30)

game.over = False#continue the game with a new game loop
while not game.over:
    game.processInput()
    bk.draw()
    game.scrollBackground("left",1)
    knight.draw()
    knight1.draw()
    knight.moveTo(400,400)
    knight1.visible = False
monsters = []#empty list
for index in range(100):#use a loop to add items
    monsters.append( Animation( "hoon-kim-gob-boss.gif",5,game,240/5,41))
for index in range(100):#use a loop to set the positions and speed
    x = randint(100,700)
    y = randint(100,300)
    monsters[index].moveTo(-x, y)
    #Zero degrees moves a graphics up
    monsters[index].setSpeed(6,180)
    if knight.collidedWith(monster):
        game.over = True
    if knight1.collidedWith(monster):
        game.score +=1
    game.update(60)
    if keys.Pressed[K_SPACE]:
        knight1.visible = True
        knight1.moveTo(500,400)
        knight.visible = False
    if knight1.visible == False:
        knight.visible = True
    game.displayScore()
        
        
game.quit()
